from Gui import SortingApp
import tkinter as tk

if __name__ == "__main__":
    root = tk.Tk()
    app = SortingApp(root)
    root.mainloop()